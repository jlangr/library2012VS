#include "UnitTestHarness/TestHarness.h"
#include "Rental.h"
#include "Movie.h"
#include "PriceCode.h"

EXPORT_TEST_GROUP(Rental);

namespace 
{
	void SetUp()
	{
	}

	void TearDown()
	{
	}
}

TEST(Rental, Create)
{
	Movie movie("title", PriceCode::REGULAR);
	Rental rental(movie, 3);
	LONGS_EQUAL(3, rental.daysRented());
}

