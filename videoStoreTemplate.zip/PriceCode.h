#ifndef D_PriceCode_h
#define D_PriceCode_h

class PriceCode {
public:
	enum { REGULAR, NEW_RELEASE, CHILDRENS };
};

#endif
