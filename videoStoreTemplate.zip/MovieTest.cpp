#include "TestHarness.h"
#include "SimpleStringExtensions.h"
#include "Movie.h"
#include "PriceCode.h"

EXPORT_TEST_GROUP(Movie);

namespace 
{
	void SetUp()
	{
	}

	void TearDown()
	{
	}
}

TEST(Movie, Create)
{
	Movie movie("title", PriceCode::REGULAR);
	CHECK_EQUAL("title", movie.title());
	LONGS_EQUAL(PriceCode::REGULAR, movie.priceCode());
}

TEST(Movie, ChangePriceCode)
{
	Movie movie("a", PriceCode::NEW_RELEASE);
	movie.setPriceCode(PriceCode::CHILDRENS);
	LONGS_EQUAL(PriceCode::CHILDRENS, movie.priceCode());
}

